Avidyne JeppView Data Extractor Software

Revision History:

v1.2.2:

a) Updates to support EX5000 Release 7.

v1.2.1:

a) Updates to support EX500 Release 3.  

v1.2.0:

a) Updates to data loader for compatibility with Avidyne EX5000 Release 6 software, allowing use of 
USB memory devices instead of Zip drives.
b) Added data loader completion screen for removal of USB memory device and reboot of MFD after a dataload
c) Removed specific references to Zip drives.
d) Allow use of Avidyne CMax key codes of less than 23 digits, if still valid.

v1.1.0:

a) Support installShield operation by accepting input parameter as 
   the working directory.  The following are the rules for using this
   feature:

   i)   Copy sxlrt308.dll to windows directory
   ii)  Copy JeppExtractor.dat to a working directory
   ii)  Copy extractor.cfg to a working directory
   iii) Run "AviJeppDataExtractor.exe drv:\working directory"
        Note, do not put"\" at the end of working directory.


b) Added an example JeppView serial number.
c) Added an example Avidyne key.
d) Fixed spelling error on first page.
e) Fixed Julian date conversion bug for loader.
f) Changed "Upgrade" and "Downgrade" naming for loader.
g) Included Help files for use by Extractor.

v1.0.0:

a) Initial Release






 

